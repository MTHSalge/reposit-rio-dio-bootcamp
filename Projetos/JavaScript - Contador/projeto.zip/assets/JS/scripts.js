var CurrentNumberWrapper = document.getElementById('currentNumber');
let count = 0;
const CURRENT_NUMBER = document.getElementById('currentNumber');

function red(){
    if(CURRENT_NUMBER<0){
        document.getElementById('currentNumber').style.color='red';
    }
}

function increment(){
    if(CURRENT_NUMBER==10){
        increment.disabled = true;
    }
    else{
        count++;
        CURRENT_NUMBER.innerHTML = count;
    }
}

function decrement(){
    if(CURRENT_NUMBER==0){
        decrement.disabled = true;
    }
    else{
        count--;
        CURRENT_NUMBER.innerHTML = count;
    }
}

document.getElementById('increment').addEventListener('click', increment)
document.getElementById('decrement').addEventListener('click', decrement)